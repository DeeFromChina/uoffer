package com.offer.util;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

public interface GeneratePDF {

	public void downloadPDF(HttpServletResponse response, Map<String, List<Map<String, String>>> map) throws Exception;
	
	public void downloadPDF2(HttpServletResponse response, Map<String, List<Map<String, String>>> map) throws Exception;

}
