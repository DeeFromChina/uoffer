package com.offer.util;

import java.io.File;
import java.util.Map;

import javax.mail.MessagingException;

public interface SendEmail {

	public void sendEmail(Map<String, String> emailMap) throws MessagingException;
	
	public void sendEmail1(Map<String, String> emailMap,File file) throws MessagingException;
}
