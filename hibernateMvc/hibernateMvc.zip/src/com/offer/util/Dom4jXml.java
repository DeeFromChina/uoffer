package com.offer.util;

import java.util.Map;

public interface Dom4jXml {

	public String initSqlXml(String path, Map<String, String> params) throws Exception;
}
