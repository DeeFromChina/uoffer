package com.offer.util;

public interface JSONString {
	
	public String toJson(Object obj);

}
