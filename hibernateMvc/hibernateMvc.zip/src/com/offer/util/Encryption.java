package com.offer.util;

public interface Encryption {
	public String encryption(String password) throws Exception;
}
