package com.offer.service;

import java.util.List;
import java.util.Map;

import com.offer.model.OfferInviteChat;

public interface OfferInviteChatService {

   public void saveOfferInviteChat(Map<String, String> map) throws Exception;
   
   public List<OfferInviteChat> getOfferInviteChats(Map<String, String> map) throws Exception;
   
   public OfferInviteChat getOfferInviteChat(int id) throws Exception;
   
   public void updateOfferInviteChat(OfferInviteChat offerInviteChat) throws Exception;
   
   public void deleteOfferInviteChat(String ids) throws Exception;
}
