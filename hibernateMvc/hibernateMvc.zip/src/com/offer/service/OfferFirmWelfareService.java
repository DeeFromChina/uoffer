package com.offer.service;

import java.util.List;

import com.offer.model.OfferFirmWelfare;

public interface OfferFirmWelfareService {

	public List<OfferFirmWelfare> findWelfaresByFirmId(String firmId) throws Exception;
}
