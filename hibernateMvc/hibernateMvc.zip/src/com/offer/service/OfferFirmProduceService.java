package com.offer.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.offer.model.OfferFirmProduce;

public interface OfferFirmProduceService {
   
   public List<OfferFirmProduce> getOfferFirmProduces(String id) throws Exception;

   public void saveOrUpdateOfferFirmProduce(String id, HttpServletRequest request) throws Exception; 
   
   public List<OfferFirmProduce> getOfferFirmProduces(int id) throws Exception;
   
   public void updateOfferFirmProduce(OfferFirmProduce offerFirmProduce) throws Exception;
   
   public void deleteOfferFirmProduce(String ids) throws Exception;
   
   public void saveOfferFirmProduce(Map<String, String> map) throws Exception;
}
