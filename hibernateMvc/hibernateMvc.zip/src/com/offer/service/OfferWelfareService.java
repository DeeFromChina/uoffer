package com.offer.service;

import java.util.List;

import com.offer.model.OfferWelfare;

public interface OfferWelfareService {
	
	public List<OfferWelfare> findAll() throws Exception;

}
