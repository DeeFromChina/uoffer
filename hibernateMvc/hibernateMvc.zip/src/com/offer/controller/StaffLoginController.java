package com.offer.controller;

import org.springframework.stereotype.Controller;

@Controller
public class StaffLoginController extends BaseController {

}
