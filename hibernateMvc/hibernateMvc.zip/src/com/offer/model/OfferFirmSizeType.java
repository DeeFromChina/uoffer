package com.offer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "offer_firm_size_type")
public class OfferFirmSizeType {

	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "offerFirmSizeType")
	private String offerFirmSizeType;
	
	@Column(name = "type")
	private int type;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOfferFirmSizeType() {
		return offerFirmSizeType;
	}

	public void setOfferFirmSizeType(String offerFirmSizeType) {
		this.offerFirmSizeType = offerFirmSizeType;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}
