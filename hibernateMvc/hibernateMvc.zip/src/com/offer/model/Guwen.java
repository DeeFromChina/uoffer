package com.offer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Guwen")
public class Guwen {

	@Id
	@GeneratedValue
	@Column(name = "id")
	private String id;

	@Column(name = "GW_phone")
	private String GWphone;

	@Column(name = "GW_emil")
	private String GWemil;

	public String getId() {
		return id;
	}

	public String getGWphone() {
		return GWphone;
	}

	public void setGWphone(String gWphone) {
		GWphone = gWphone;
	}

	public String getGWemil() {
		return GWemil;
	}

	public void setGWemil(String gWemil) {
		GWemil = gWemil;
	}

	
}
