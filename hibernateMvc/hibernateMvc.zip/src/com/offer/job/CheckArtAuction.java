package com.offer.job;

public interface CheckArtAuction {
   
   public void executeCheck() throws Exception;

}
